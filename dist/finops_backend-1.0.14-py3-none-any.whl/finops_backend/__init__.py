# # __init__.py inside flask_project
# from flask import Flask
# from flask_cors import CORS
# import warnings

# app=Flask(__name__)
# CORS(app)
# warnings.filterwarnings("ignore")

# # Import routes to register endpoints
# from . import app as app_module