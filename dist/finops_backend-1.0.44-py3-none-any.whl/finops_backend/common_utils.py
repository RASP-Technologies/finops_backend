
def get_followup_query_prompt(query: str, tables: str, columns: str, df: str):
    followup_prompt = f'''Give me top three follow up analytical business query to the following business query:-
        {query}
        and following table and columns:-
        Tables: {tables}
        Columns:{columns}
        based on this data: 
        {df}
        Note: Follow up queries should have corresponding valid SQL queries based on the tables and columns mentioned above to fetch the data from database.Don't print the SQL query along with the question. Just print the questions.
        Note: Don't highlight the words or give any headings. just print 3 questions in seperate lines without ordering. In the following format:
        question1\nquestion2\nquestion3 
        NOTE: All three questions should be valid follow up question to the main query and different from each other'''
    return followup_prompt

def get_prompt_for_unoptimised_query(tables: str, schema: str, content: str):
    prompt = f'''
        --- given the table details with description and columns used for joins which are '|' seperated .
        ``
        TABLES : {tables}
        ``
        ---
        given the column details which are '|' seperated as following . 
        ```
        MATCHED_SCHEMA: {schema}
        ```
        Write an unoptimised GoogleSQL dialect SQL using the above column details and tables provided in details which achieves the following.
        ```
        { content }
        ```
        IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA. DO NOT USE any other column names outside of this. 
        IMPORTANT: `` Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA ``.
        IMPORTANT: Consider the sample user prompts and corresponding assistant generated queries for better suggestion. If the provided prompt matches with the sample prompts then provide the corresponding sample query as it is.
        Note : Use UNNEST for the STRUCT Datatype or ARRAY Datatype field if required to create appropriate SQL queries and JOINS.
        Note: Do not use UNNEST on a table_name and also do not use UNNEST unless data_type of the column_name is of type STRUCT or ARRAY
        IMPORTANT: Make sure the generated SQL has consistent spacing and correct formatting.
        IMPORTANT: Avoid GCP Project ID and Dataset reference in the output SQL.
        IMPORTANT: Always make this query deliberately worst performing and should have lot of scope of optimisation.
        IMPORTANT: Always make this query add CAST function to the generated query.
        IMPORTANT: Always make this query add Nested Subqueries with Unnecessary Complexity to the generated query.
        IMPORTANT: Ensure that the unoptimised query is syntactically correct with respect to the context provided
        IMPORTANT: Always give the response in the format Unoptimised Query:-'generated_query' and don't use any other separator apart from :- to seggregate Unoptimised Query with the generated query.
    '''
    return prompt

def get_prompt_for_optimised_query(tables: str, schema: str, content: str):
    prompt = f'''
    --- given the table details with description and columns used for joins . which are '|' seperated .
    ``
    TABLES : {tables}
    ``
    ---
    given the column details which are '|' seperated as following . 
    ```
    MATCHED_SCHEMA: {schema}

    ```
    Write an GoogleSQL dialect SQL using the above column details and tables provided in details which achieves the following.
    ```
    { content }
    ```
    IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA. DO NOT USE any other column names outside of this. 
    IMPORTANT: `` Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA ``.
    IMPORTANT: Consider the sample user prompts and corresponding assistant generated queries for better suggestion. If the provided prompt matches with the sample prompts then provide the corresponding sample query as it is.
    Note : use safe divide , safe cast where ever possible. Avoid using alias names in groupby and orderby sections.
    Note : Use UNNEST for the Struct Datatype or Struct Array Datatype field if required to create appropriate SQL queries and JOINS.
    IMPORTANT: Make sure the generated SQL has consistent spacing and correct formatting.
    IMPORTANT: Use GROUP BY if the SQL query requires aggegration for example if you see COUNT in the query
    IMPORTANT: Avoid GCP Project ID and Dataset reference in the output SQL.
    IMPORTANT: Optimise the query for better performance by improving indexing, using efficient joins, reducing unnecessary calculations, and avoiding redundant operations where possible
    IMPORTANT: Remove cast function from the resultant query whenever it is feasible. 
    IMPORTANT: Use appropriate Biqquery functions as per the data_type, for example, use TIMESTAMP_SUB function only for TIMESTAMP data_type and when using TIMESTAMP_SUB provide INTERVAL in DAYS. 
    IMPORTANT: Whenever the SQL query involves a TIMESTAMP_SUB function, always convert months to days by assuming 1 month = 30 days. Use INTERVAL arithmetic accordingly (e.g., DATE_ADD(timestamp_column, INTERVAL 30 * n DAY)). 
    IMPORTANT: If there is no scope of optimising the query then return the original unoptimised query itself.
    IMPORTANT: Always give the response in the format Optimised Query:-'generated_query' and don't use any other separator apart from :- to seggregate Optimised Query with the generated query.

    '''
    return prompt

def get_prompt_for_analytical_intent(query: str):
    prompt = f'''Following query is the analytical query or not: 
                {query}
                Just print True or False and nothing else'''
    return prompt

def get_prompt_for_sql_query_verification(query: str):
    prompt = f'''Check if the follwing query is a SQL query or not: 
                {query}
                Just print True or False and nothing else'''
    return prompt

def get_sql_injection_prompt(sql_query: str) -> str:
    SQL_INJECTION_PROMPT = f"""
        You are a cybersecurity expert specializing in SQL injection detection.  
        Analyze the given SQL query and determine if it **has SQL injection intent**.  

        **Rules for detection:**  
        - Query contains patterns like `OR 1=1`, `UNION SELECT`, `--`, `DROP TABLE`, etc.  
        - Use of **string concatenation** that modifies query logic dynamically.  
        - **Stacked queries** (`;` multiple statements in one query).  
        - **Unusual use of quotes or comments** that might escape intended query structure.  

        **Return only `True` or `False` (without any explanation):**  
        - **`True`** → If SQL injection risk is detected.  
        - **`False`** → If no SQL injection risk is detected.  

        **Analyze this SQL query and return only True or False:**
        {sql_query}
    """
    return SQL_INJECTION_PROMPT
# TEMPLATE = f'''
    # --- given the table details with description and columns used for joins . which are '|' seperated .
    # ``
    # TABLES : {tables}
    # ``
    # ---
    # given the column details which are '|' seperated as following . 
    # ```
    # MATCHED_SCHEMA: {schema}


    # ```
    # ## **Instructions for SQL Generation**
    # 1. **Use ONLY the column names listed in `MATCHED_SCHEMA`.**  
    # **DO NOT** introduce new column names that are not explicitly listed.  
    # **DO NOT** guess or create columns based on assumptions.

    # 2. **Column-to-Table Mapping:**  
    # - Each `column_name` in `MATCHED_SCHEMA` is strictly linked to its `table_name`.  
    # - If a column is not associated with a table, **DO NOT USE IT**.

    # 3. **Follow GoogleSQL Syntax:**  
    # - Use **SAFE_DIVIDE()** and **SAFE_CAST()** wherever applicable.
    # - Avoid aliasing table names in **GROUP BY** and **ORDER BY**.

    # 4. **Strictly Follow Example Queries:**  
    # - Use the style and structure of queries provided in the **Sample Queries (messages.json)**.  
    # - **DO NOT MODIFY column names** or their meanings.  

    # 5. **Formatting Guidelines:**  
    # - The SQL must be correctly formatted with **consistent spacing**.
    # - **DO NOT** include unnecessary joins or subqueries.

    # ## **Query to Generate**
    # ```
    # { content }
    # ```
    # **IMPORTANT:**
    # - If a required column is missing from `MATCHED_SCHEMA`, **DO NOT generate the query** and return `"INSUFFICIENT DATA"` instead.
    # - **DO NOT generate or assume additional columns**. Use only what's explicitly mentioned.
    # IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA. DO NOT USE any other column names outside of this. 
    # IMPORTANT: `` Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA ``.
    # Note : use safe divide , safe cast where ever possible. Avoid using alias names in groupby and orderby sections.
    # IMPORTANT: Make sure the generated SQL has consistent spacing and correct formatting.
    # IMPORTANT: Avoid GCP Project ID and Dataset reference in the output SQL.
    # IMPORTANT: Always make this query deliberately inefficient and should have scope of optimisation.
    # IMPORTANT: Ensure that the unoptimised query is syntactically correct with respect to the context provided

    # '''