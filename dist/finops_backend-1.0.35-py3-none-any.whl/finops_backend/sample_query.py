SAMPLE_QUERY = {
    '''SELECT 'Real Time Dashboard' AS report_name, CASE WHEN cm_event_state_updates.statemachineid = 'operational_status' AND cm_event_state_updates.state.id = 'in_progress' THEN cm_event_assignee_update.username WHEN cm_event_state_updates.state.id IN ( "on_hold", "unreviewed", "fraud", "genuine", "contact_customer", "closed" ) THEN cm_event_state_updates.username END AS analyst_full_name, cm_event_state_updates.payload.schema.alert_id AS alert_id, timestamp_millis( cm_event_state_updates.updatedAt ) AS alert_action_timestamp, cm_event_queue_changed.queueid AS queue_id, queue_reference.Queue_Name AS queue_name, cm_event_state_updates.statemachineid AS statemachineid, cm_event_state_updates.state.id AS stateid, cm_event_arrival.id.identifier AS lifecycle_id, timestamp_diff( timestamp_millis( cm_event_state_updates.updatedAt ), timestamp_millis( cm_event_state_updates_lag.updated_prev ), SECOND ) AS time_diff, CASE WHEN lower( cm_event_state_updates.state.id ) IN ( 'fraud', 'genuine', 'in_progress', 'on_hold', 'closed' ) THEN cm_event_state_updates.name END AS reason_updated, timestamp('2025-02-28 14:00:10.000') AS load_datetime FROM ( SELECT *, lag(username) over( PARTITION BY identifier ORDER BY updatedat DESC ) AS user_next FROM cm_event_state_updates_vw WHERE updatedTimestamp >= timestamp('2025-01-28 14:00:10.000') AND updatedTimestamp < timestamp('2025-03-28 14:00:10.000') ) cm_event_state_updates LEFT JOIN ( SELECT * FROM ( SELECT *, ROW_NUMBER() OVER( PARTITION BY identifier ORDER BY updatedAT DESC ) AS rownum FROM cm_event_assignee_update LEFT JOIN unnest(ids) ) WHERE rownum = 1 ) cm_event_assignee_update ON cm_event_state_updates.identifier = cm_event_assignee_update.identifier LEFT JOIN ( SELECT * FROM ( SELECT *, ROW_NUMBER() OVER( PARTITION BY id.identifier ORDER BY timestamp(cm_event_arrival.timestamp) DESC ) AS rownum FROM cm_event_arrival WHERE lower( cm_event_arrival.id.payload.schema.event_type ) NOT IN ('feedback') ) WHERE rownum = 1 ) cm_event_arrival ON cm_event_state_updates.identifier = cm_event_arrival.id.identifier LEFT JOIN ( SELECT * FROM ( SELECT cm_event_queue_changed.timestamp AS timestamp, cm_event_queue_changed.queueid, identifier, ROW_NUMBER() OVER( PARTITION BY identifier ORDER BY timestamp( cm_event_queue_changed.timestamp ) DESC ) AS rownum FROM cm_event_queue_changed LEFT JOIN unnest(ids) WHERE queueid IS NOT NULL ) WHERE rownum = 1 ) cm_event_queue_changed ON cm_event_state_updates.identifier = cm_event_queue_changed.identifier LEFT JOIN ( SELECT *, lag(username) over( PARTITION BY identifier ORDER BY updatedat DESC ) AS user_next, lag(updatedat) OVER ( PARTITION BY identifier ORDER BY updatedat ) AS updated_prev, lag(state.id) OVER ( PARTITION BY identifier ORDER BY updatedat ) AS stateid_prev FROM cm_event_state_updates_vw ) cm_event_state_updates_lag ON cm_event_state_updates_lag.identifier = cm_event_state_updates.identifier AND cm_event_state_updates.updatedat = cm_event_state_updates_lag.updatedat LEFT JOIN FZ_EU_REPORT_MARTS_TABLES_DEV.queue_reference ON cm_event_queue_changed.queueid = queue_reference.Queue_Id WHERE lower(cm_event_arrival.id.channelid) IN ('transfers') AND lower( cm_event_state_updates.statemachineid ) IN ("operational_status", "status") AND lower( cm_event_state_updates.state.id ) IN ( "on_hold", "in_progress", "unreviewed", "fraud", "genuine", "contact_customer", "pending_manual_closure", "pending_crypto_reversal_sms", "pending_bot_closure", "closed", "wait_to_contact_customer" ) AND lower( cm_event_arrival.id.payload.schema.event_type ) IN ('transfer_initiation') AND cm_event_arrival.alert = TRUE'''
    :
    '''
        SELECT 
            'Real Time Dashboard' AS report_name,

            CASE 
                WHEN cm_event_state_updates.statemachineid = 'operational_status' 
                    AND cm_event_state_updates.state.id = 'in_progress' 
                THEN cm_event_assignee_update.username 
                WHEN cm_event_state_updates.state.id IN ("on_hold", "unreviewed", "fraud", "genuine", "contact_customer", "closed") 
                THEN cm_event_state_updates.username 
            END AS analyst_full_name,

            cm_event_state_updates.payload.schema.alert_id AS alert_id,
            TIMESTAMP_MILLIS(cm_event_state_updates.updatedAt) AS alert_action_timestamp,
            cm_event_queue_changed.queueid AS queue_id,
            queue_reference.Queue_Name AS queue_name,
            cm_event_state_updates.statemachineid AS statemachineid,
            cm_event_state_updates.state.id AS stateid,
            cm_event_arrival.id.identifier AS lifecycle_id,

            TIMESTAMP_DIFF(
                TIMESTAMP_MILLIS(cm_event_state_updates.updatedAt), 
                TIMESTAMP_MILLIS(cm_event_state_updates_lag.updated_prev), 
                SECOND
            ) AS time_diff,

            CASE 
                WHEN LOWER(cm_event_state_updates.state.id) IN ('fraud', 'genuine', 'in_progress', 'on_hold', 'closed') 
                THEN cm_event_state_updates.name 
            END AS reason_updated,

            TIMESTAMP('2025-02-28 14:00:10.000') AS load_datetime

        FROM 
        (
            SELECT *, 
                LAG(username) OVER (PARTITION BY identifier ORDER BY updatedAt DESC) AS user_next   
            FROM cm_event_state_updates_vw 
            WHERE updatedTimestamp BETWEEN TIMESTAMP('2025-01-28 14:00:10.000') 
                                    AND TIMESTAMP('2025-03-28 14:00:10.000')
        ) cm_event_state_updates

        LEFT JOIN (
            SELECT * 
            FROM (
                SELECT *, 
                    ROW_NUMBER() OVER (PARTITION BY identifier ORDER BY updatedAT DESC) AS rownum 
                FROM cm_event_assignee_update 
                LEFT JOIN UNNEST(ids)
            ) 
            WHERE rownum = 1
        ) cm_event_assignee_update
        ON cm_event_state_updates.identifier = cm_event_assignee_update.identifier

        LEFT JOIN (
            SELECT * 
            FROM (
                SELECT *, 
                    ROW_NUMBER() OVER (PARTITION BY id.identifier ORDER BY TIMESTAMP(cm_event_arrival.timestamp) DESC) AS rownum 
                FROM cm_event_arrival 
                WHERE LOWER(cm_event_arrival.id.payload.schema.event_type) NOT IN ('feedback') 
            ) 
            WHERE rownum = 1
        ) cm_event_arrival
        ON cm_event_state_updates.identifier = cm_event_arrival.id.identifier

        LEFT JOIN (
            SELECT identifier, queueid, timestamp
            FROM (
                SELECT identifier, 
                    cm_event_queue_changed.timestamp, 
                    cm_event_queue_changed.queueid, 
                    ROW_NUMBER() OVER (PARTITION BY identifier ORDER BY TIMESTAMP(cm_event_queue_changed.timestamp) DESC) AS rownum 
                FROM cm_event_queue_changed 
                LEFT JOIN UNNEST(ids)
                WHERE queueid IS NOT NULL
            ) 
            WHERE rownum = 1
        ) cm_event_queue_changed
        ON cm_event_state_updates.identifier = cm_event_queue_changed.identifier

        LEFT JOIN (
            SELECT identifier, updatedAt, username,
                LAG(updatedAt) OVER (PARTITION BY identifier ORDER BY updatedAt) AS updated_prev
            FROM cm_event_state_updates_vw
        ) cm_event_state_updates_lag
        ON cm_event_state_updates_lag.identifier = cm_event_state_updates.identifier
        AND cm_event_state_updates.updatedAt = cm_event_state_updates_lag.updatedAt                        

        LEFT JOIN queue_reference
        ON cm_event_queue_changed.queueid = queue_reference.Queue_Id

        WHERE 
            LOWER(cm_event_arrival.id.channelid) IN ('transfers')
            AND LOWER(cm_event_state_updates.statemachineid) IN ("operational_status", "status")
            AND LOWER(cm_event_state_updates.state.id) IN (
                "on_hold", "in_progress", "unreviewed", "fraud", "genuine", 
                "contact_customer", "pending_manual_closure", 
                "pending_crypto_reversal_sms", "pending_bot_closure", "closed", 
                "wait_to_contact_customer"
            )
            AND LOWER(cm_event_arrival.id.payload.schema.event_type) IN ('transfer_initiation')
            AND cm_event_arrival.alert = TRUE;
    '''
}