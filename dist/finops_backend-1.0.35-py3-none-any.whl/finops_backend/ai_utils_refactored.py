from langchain.embeddings import OpenAIEmbeddings
import pickle
import os
from langchain.document_loaders import JSONLoader
from langchain.vectorstores import FAISS
import json
import os 
from openai import OpenAI
import plotly.express as px
import configparser
import httpx
import requests
from langchain_openai import AzureOpenAIEmbeddings
from finops_backend.common_utils import *

# Read the configurations
config = configparser.ConfigParser()
config.read('config/config.ini')
os.environ['SSL_CERT_FILE']=config.get('OpenAI', 'cert_path')
os.environ['TIKTOKEN_CACHE_DIR']=config.get('OpenAI', 'TIKTOKEN_CACHE_DIR')

# Database Config
BQ_PROJECT = config.get('Database', 'bigquery_project')
BQ_DATASET = config.get('Database', 'bigquery_dataset')
BQ_SERVICE_ACCOUNT_FILE_PATH = config.get('Database', 'service_account_file')
DB_COLUMN_PATH = config.get('Database', 'columns_path')
DB_TABLES_PATH = config.get('Database', 'tables_path')

# OpenAI Config
OPENAI_BASE_URL=config.get('OpenAI', 'base_url')
OPENAI_BASE_EMBEDDING_URL=config.get('OpenAI', 'base_embedding_url')
OPENAI_PROJECT_ID=config.get('OpenAI', 'project_id')
OPENAI_API_KEY=config.get('OpenAI', 'api_key')
OPENAI_API_VERSION=config.get('OpenAI', 'api_version')
OPENAI_MODEL=config.get('OpenAI', 'model')
OPENAI_EMBEDDING_MODEL=config.get('OpenAI', 'embedding_model')
OPENAI_AZURE_DEPLOYMENT=config.get('OpenAI', 'azure_deployment')

# Create a custom httpx client with SSL verification disabled
custom_http_client = httpx.Client(verify=False)
custom_http_client_embedded = httpx.AsyncClient(verify=False)


# -------------------------------------------------------------------------------

os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
openai_api_key = os.environ.get('OPENAI_API_KEY')

# -------------------------------------------------------------------------------

if OPENAI_BASE_EMBEDDING_URL:
    print("start call for embedding\n")
    headers = {
        'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"embedding"}}',
        'Authorization-Type': 'genai',
        'Authorization': f'Bearer {OPENAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    embedding = AzureOpenAIEmbeddings(azure_endpoint=OPENAI_BASE_EMBEDDING_URL,
                                     openai_api_key=OPENAI_API_KEY,
                                     openai_api_version=OPENAI_API_VERSION,
                                     deployment=OPENAI_EMBEDDING_MODEL,
                                     default_headers=headers)
else:
    embedding = OpenAIEmbeddings(
    model=OPENAI_EMBEDDING_MODEL
    # With the `text-embedding-3` class
    # of models, you can specify the size
    # of the embeddings you want returned.
    # dimensions=1024
    )

def describe_bot(prompt, llm_type):
    
    if llm_type == 'openai':
        # Initialize OpenAI client with or without base_url
        if OPENAI_BASE_URL:
            headers = {
                'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
                'Authorization-Type': 'genai',
                'Authorization': f'Bearer {OPENAI_API_KEY}',
                'Content-Type': 'application/json'
            }

            data = {
                "messages": [{"role": "user", "content": f"{prompt}"}],
                "temperature": 0.0 ,
                "top_p": 0.8,
                "frequency_penalty": 0,
                "presence_penalty": 0,
                "max_tokens": 2919,
                "stop": None,
                "stream": False
            }

            print("Request URL: ", OPENAI_BASE_URL)
            print("Request Headers: ", headers)
            print("Request Model:", OPENAI_MODEL)
            
            response = requests.post(OPENAI_BASE_URL , headers=headers, json=data, verify=False )
            response = json.loads(response.text)

            print("Response:", response)

            answer = response['choices'][0]['message']['content'].strip()

        else:
            client = OpenAI()
            response = client.chat.completions.create(
                model = OPENAI_MODEL,
                messages = [{"role": "system", "content": "You are Business Analyst"},{"role": "user", "content": f"{prompt}"}
                            ],
                temperature = 0.0
            )
            answer = response.choices[0].message.content.strip()

            OpenAI.api_key = os.getenv('OPENAI_API_KEY')
            print("Request URL: ", client.base_url)
            print("Request Headers: ", client.default_headers)
            print("Request Model:", OPENAI_MODEL)
            print("Response:", response)

        return answer
        pass

def predict(content: str, schema: str, tables: str, llm):
    verbose: bool = False

    # Load middle conversation from JSON
    with open("config/messages.json", "r") as file:
        middle_conversation = json.load(file)
    
    # Define system instruction
    system_message = {
        "role": "system",
        "content": "You are an Analyst and you are hands-on in BigQuery SQL. Respond only with SQL queries with no explanation."
    }

    TEMPLATE = get_prompt_for_unoptimised_query(tables, schema, content)
    
    # Define the last user prompt dynamically
    last_prompt = {
        "role": "user",
        "content": f"{TEMPLATE}"
    }

    prompt_messages = [system_message] + middle_conversation + [last_prompt]

    # print("--- Prompt Template ----\n")
    # print(prompt_messages)

    answer = prompt_llm(prompt_messages)
    return answer
    pass

def predict_optimised_query(unoptimised_query: str, schema: str, tables: str, llm):
    verbose: bool = False
    
    # Load middle conversation from JSON
    with open("config/messages.json", "r") as file:
        middle_conversation = json.load(file)
    
    # Define system instruction
    system_message = {
        "role": "system",
        "content": "You are an Analyst and you are hands-on in BigQuery SQL. Respond only with SQL queries with no explanation."
    }
    
    TEMPLATE = get_prompt_for_optimised_query(tables, schema, unoptimised_query)
    
    # Define the last user prompt dynamically
    last_prompt = {
        "role": "user",
        "content": f"{TEMPLATE}"
    }
    
    prompt_messages = [system_message] + middle_conversation + [last_prompt]
    
    answer = prompt_llm(prompt_messages)

    return answer.split("Optimised Query:-")[1]

    pass

def prompt_llm(messages_prompt):
    
    # Initialize OpenAI client with or without base_url
    if OPENAI_BASE_URL:
        headers = {
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }

        data = {
            "messages": messages_prompt,
            "temperature": 0.0 ,
            "top_p": 0.8,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 2919,
            "stop": None,
            "stream": False
        }
        print("Request URL: ", OPENAI_BASE_URL)
        print("Request Headers: ", headers)
        print("Request Model:", OPENAI_MODEL)
        response = requests.post(OPENAI_BASE_URL , headers=headers, json=data, verify=False )
        print("Response:", response)
        response = json.loads(response.text)
        answer = response['choices'][0]['message']['content'].strip()

    else:
        client = OpenAI()
        response = client.chat.completions.create(
            model = OPENAI_MODEL,
            messages = messages_prompt,
            temperature = 0.0
        )
        answer = response.choices[0].message.content.strip()
        print("Request URL: ", client.base_url)
        print("Request Headers: ", client.default_headers)
        print("Request Model:", OPENAI_MODEL)
        print("Response:", response)
    return answer

def create_and_save_faiss(file_path, faiss_index_path, doc_store_path):
    # Load documents
    documents = JSONLoader(file_path=file_path, jq_schema='.', text_content=False, json_lines=True).load()
    
    # Create FAISS vector store
    db = FAISS.from_documents(documents=documents, embedding=embedding)

    # Save FAISS index
    db.save_local(faiss_index_path)

    # Save documents separately using pickle
    with open(doc_store_path, "wb") as f:
        pickle.dump(documents, f)
    
    print("FAISS index and document store saved successfully.")

# Function to load FAISS vector store
def load_faiss(faiss_index_path, doc_store_path):
    # Load FAISS index
    db = FAISS.load_local(faiss_index_path, embeddings=embedding, allow_dangerous_deserialization=True)
    
    # Load stored documents
    if os.path.exists(doc_store_path):
        with open(doc_store_path, "rb") as f:
            documents = pickle.load(f)
    else:
        documents = None

    return db, documents

def return_tables_matched(query, db=''):
    
    documents = JSONLoader(file_path=DB_TABLES_PATH, jq_schema='.', text_content=False, json_lines=True).load()
    db = FAISS.from_documents(documents=documents, embedding=embedding)
    retriever = db.as_retriever(search_type='mmr', search_kwargs={'k': 5, 'lambda_mult': 1})
    matched_documents = retriever.get_relevant_documents(query=query)
    matched_tables = []
    for document in matched_documents:
        page_content = document.page_content
        page_content = json.loads(page_content)
        table_name = page_content['table_name']
        desc=page_content['description']
        example_queries=page_content['example_queries']
        matched_tables.append(f'{table_name}|{desc}|{example_queries}')
    matched_tables = '\n'.join(matched_tables)    
    return matched_tables
    pass

def return_matched_columns(query, db):
    print("----Get Embeddings-----\n")
    documents = JSONLoader(file_path=DB_COLUMN_PATH, jq_schema='.', text_content=False, json_lines=True).load()
    db = FAISS.from_documents(documents=documents, embedding=embedding)
    search_kwargs = {
        'k': 20
    }
    retriever = db.as_retriever(search_type='similarity', search_kwargs=search_kwargs)
    matched_columns = retriever.get_relevant_documents(query=query)

    return matched_columns
    pass

def return_columns_cleaned(query, db=''):
    
    matched_columns = return_matched_columns(query, db)
    
    matched_columns_filtered = []
    # LangChain filters does not support multiple values at the moment
    for i, column in enumerate(matched_columns):
        page_content = json.loads(column.page_content)
        matched_columns_filtered.append(page_content)

    matched_columns_cleaned = []
    for doc in matched_columns_filtered:
        table_name = doc['table_name']
        column_name = doc['column_name']
        data_type = doc['data_type']
        col_desc = doc['description']
        matched_columns_cleaned.append(f'table_name={table_name}|column_name={column_name}|data_type={data_type}|description={col_desc}') 
    matched_columns_cleaned = '\n'.join(matched_columns_cleaned)
    return matched_columns_cleaned
    pass

def get_sql_query_openai(query,llm):
    columns_schema = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    # print("Columns Schema from FAISS")
    # print(columns_schema)
    # print("Tables Schema from FAISS")
    # print(tables)
    # Unoptimsed Query
    result = predict(query,columns_schema,tables,llm)
    # print("output sql query", result)
    cleaned_sql = result.replace('```', '').replace('sql','')
    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    # print('sql', cleaned_sql_1)
    # sql=result.replace('```', ''''')
    
    # Optimised Query
    result_optimised = predict_optimised_query(cleaned_sql_1, columns_schema, tables, llm)
    cleaned_optimised_sql = result_optimised.replace('```', '').replace('sql','')
    cleaned_optimised_sql_1 = ' '.join(cleaned_optimised_sql.split())

    return cleaned_sql_1, cleaned_optimised_sql_1, columns_schema, tables
    pass

def get_unoptimised_sql_query_openai(query,llm):
    columns_schema = return_columns_cleaned(query)
    tables = return_tables_matched(query)
    # print("Columns Schema from FAISS")
    # print(columns_schema)
    # print("Tables Schema from FAISS")
    # print(tables)
    # Unoptimsed Query
    result = predict(query,columns_schema,tables,llm)
    # print("output sql query", result)
    cleaned_sql = result.replace('```', '').replace('sql','')
    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    # print('sql', cleaned_sql_1)
    # sql=result.replace('```', ''''')

    return cleaned_sql_1, columns_schema, tables
    pass

def get_optimised_sql_query_openai(query, llm):
    columns_schema = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    # print("Columns Schema from FAISS")
    # print(columns_schema)
    # print("Tables Schema from FAISS")
    # print(tables)
    # Optimised Query
    result_optimised = predict_optimised_query(query, columns_schema, tables, llm)
    cleaned_optimised_sql = result_optimised.replace('```', '').replace('sql','')
    cleaned_optimised_sql_1 = ' '.join(cleaned_optimised_sql.split())

    return cleaned_optimised_sql_1, columns_schema, tables
    pass

def generate_sql(query, columns_schema, tables):
    
    llm = "openai"
    
    result = predict(query,columns_schema,tables,llm)
    
    sql = result.replace('```', '').replace('sql','')
    
    sql = ' '.join(sql.split())
    
    return sql

def generate_visualization(df, color_scheme='Plasma'):
    cols = df.columns 
    col_x = cols[-2]
    col_y = cols[-1]
    
    print("X Column data type:", df[col_x].dtype)
    print("Y Column data type:", df[col_y].dtype)
    
    # Determine the type of plot based on the data type of the columns
    if df[col_x].dtype == 'object' or df[col_y].dtype == 'object':
        # Bar plot for categorical data
        fig = px.bar(df, x=col_x, y=col_y, title='Insight Visualization', color=col_y, color_continuous_scale=color_scheme)
    elif df[col_x].dtype == 'datetime':
        # Line plot for time series data
        fig = px.line(df, x=col_x, y=col_y, title='Insight Visualization', color=col_y, color_continuous_scale=color_scheme)
    else:
        # Scatter plot for numerical data
        fig = px.scatter(df, x=col_x, y=col_y, title='Insight Visualization', color=col_y, color_continuous_scale=color_scheme)
    
    fig.show()
    fig.write_image("image_desc.png")

def sample_gen(df,query,tables, columns, llm_type):
    sample = describe_bot(get_followup_query_prompt(query, tables, columns, df), llm_type)
    return sample
    pass