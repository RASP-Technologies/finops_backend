"""
Utility functions for BigQuery cost calculations.
"""
import configparser
import os
import logging
from datetime import datetime


def get_pricing_config():
    """
    Get the pricing configuration from the pricing_config.ini file.

    Returns:
        dict: Pricing configuration values
    """
    config = configparser.ConfigParser()
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'pricing_config.ini')
    config.read(config_path)

    return {
        'query_price_per_tb': float(config.get('Pricing', 'query_price_per_tb', fallback='5.0')),
        'safety_margin_percentage': float(config.get('Pricing', 'safety_margin_percentage', fallback='5')),
        'enable_cost_logging': config.getboolean('Logging', 'enable_cost_logging', fallback=True),
        'cost_log_file': config.get('Logging', 'cost_log_file', fallback='cost_estimates.log'),
        'default_daily_budget_usd': float(config.get('Budget', 'default_daily_budget_usd', fallback='0'))
    }


def calculate_query_cost(bytes_processed):
    """
    Calculate the cost of a query based on bytes processed.

    Args:
        bytes_processed (int): Number of bytes processed by the query

    Returns:
        dict: Cost information including bytes, TB, and USD cost
    """
    # Get pricing configuration
    pricing_config = get_pricing_config()

    # Convert bytes to terabytes
    tb_processed = bytes_processed / (1024 ** 4)

    # Calculate base cost
    base_cost = tb_processed * pricing_config['query_price_per_tb']

    # Apply safety margin
    safety_margin = base_cost * (pricing_config['safety_margin_percentage'] / 100)
    total_cost = base_cost + safety_margin

    # Log cost estimate if enabled
    if pricing_config['enable_cost_logging']:
        log_cost_estimate(bytes_processed, tb_processed, total_cost)

    return {
        'bytes_processed': bytes_processed,
        'megabytes_processed': bytes_processed / (1024 ** 2),
        'gigabytes_processed': bytes_processed / (1024 ** 3),
        'terabytes_processed': tb_processed,
        'base_cost_usd': round(base_cost, 6),
        'safety_margin_usd': round(safety_margin, 6),
        'estimated_cost_usd': round(total_cost, 6),
        'price_per_tb_usd': pricing_config['query_price_per_tb']
    }


def log_cost_estimate(bytes_processed, tb_processed, cost_usd):
    """
    Log a cost estimate to the cost log file.

    Args:
        bytes_processed (int): Number of bytes processed
        tb_processed (float): Number of terabytes processed
        cost_usd (float): Estimated cost in USD
    """
    pricing_config = get_pricing_config()
    log_file = pricing_config['cost_log_file']

    # Create logger
    logger = logging.getLogger('cost_estimator')
    logger.setLevel(logging.INFO)

    # Create file handler if not already created
    if not logger.handlers:
        handler = logging.FileHandler(log_file)
        formatter = logging.Formatter('%(asctime)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    # Log the cost estimate
    logger.info(
        f"Cost Estimate: {bytes_processed:,} bytes ({tb_processed:.6f} TB) = ${cost_usd:.6f}"
    )


def format_bytes(bytes_value):
    """
    Format bytes into a human-readable format.

    Args:
        bytes_value (int): Number of bytes

    Returns:
        str: Formatted string (e.g., "1.23 MB")
    """
    if bytes_value < 1024:
        return f"{bytes_value} B"
    elif bytes_value < 1024 ** 2:
        return f"{bytes_value / 1024:.2f} KB"
    elif bytes_value < 1024 ** 3:
        return f"{bytes_value / (1024 ** 2):.2f} MB"
    elif bytes_value < 1024 ** 4:
        return f"{bytes_value / (1024 ** 3):.2f} GB"
    else:
        return f"{bytes_value / (1024 ** 4):.2f} TB"