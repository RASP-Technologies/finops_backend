"""
BigQuery cost estimation functions using DryRun.
"""
from google.cloud import bigquery
from datetime import datetime
from google.oauth2 import service_account
import configparser
import json
import os

from finops_backend.cost_utils import calculate_query_cost, format_bytes

config = configparser.ConfigParser()
config.read('config/config.ini')

# Database Config
BQ_PROJECT = config.get('Database', 'bigquery_project')
BQ_DATASET = config.get('Database', 'bigquery_dataset')
BQ_SERVICE_ACCOUNT_FILE_PATH = config.get('Database', 'service_account_file')

def estimate_query_cost(query):
    """
    Estimate the cost of a BigQuery SQL query without executing it.

    Args:
        query (str): SQL query to estimate

    Returns:
        dict: Cost estimate information
    """

    # Custom connection details for BigQuery
    credentials = service_account.Credentials.from_service_account_file(
        BQ_SERVICE_ACCOUNT_FILE_PATH
    )
    client = bigquery.Client(credentials=credentials, project=BQ_PROJECT)

    # Configure job for dry run
    job_config = bigquery.QueryJobConfig(
        dry_run=True,
        use_query_cache=False,
        default_dataset=f"{BQ_PROJECT}.{BQ_DATASET}"
    )
    print(f"Default dataset configured as: {job_config.default_dataset}")
    try:
        # Run the query as a dry run
        start_time = datetime.now()
        query_job = client.query(query, job_config=job_config)
        end_time = datetime.now()

        # Calculate elapsed time
        elapsed_ms = (end_time - start_time).total_seconds() * 1000

        # Get bytes that would be processed
        bytes_processed = query_job.total_bytes_processed or 0

        # Calculate cost
        cost_info = calculate_query_cost(bytes_processed)

        # Add additional information
        cost_info.update({
            'query': query,
            'elapsed_ms': elapsed_ms,
            'status': 'success',
            'timestamp': datetime.now().isoformat()
        })

        return cost_info

    except Exception as e:
        # Handle errors
        return {
            'status': 'error',
            'error_message': str(e),
            'query': query,
            'timestamp': datetime.now().isoformat()
        }