import zipfile

with zipfile.ZipFile("dist/finops_backend-1.0.18-py3-none-any.whl") as f:
    f.extractall('dist/finops_backend')