import warnings
from flask import Flask, render_template
from flask import request
# from ui_streamlit_v5_turbo import *
from flask import json
from flask import jsonify
from langchain_community.chat_models import ChatVertexAI
from openai import OpenAI
from werkzeug.exceptions import HTTPException
from collections import OrderedDict
import json
from datetime import datetime
from pandas.api.types import is_datetime64_any_dtype as is_datetime
from flask_cors import CORS
from google.cloud import bigquery
import nltk
from nltk.corpus import words
import pandas as pd
# from google.cloud.aiplatform.gapic import ChatVertexAI
# nltk.download('words')
from google.oauth2 import service_account
# english_words = words.words()
import configparser
import httpx
import sqlparse
import time
from finops_backend.ai_utils_refactored import *
from finops_backend.common_utils import *
from finops_backend.sample_query import *

app=Flask(__name__)
# CORS(app)
cors = CORS(app, resources={r"/*": {
    "origins": "*",  # In production, specify exact origins instead of *
    "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    "allow_headers": ["*", "Authorization", "Accept", "X-Requested-With"],
    "expose_headers": ["Content-Type", "X-Total-Count"],
    "supports_credentials": False,  # Set to True if using cookies/auth
    "max_age": 3600  # Cache preflight request results for 1 hour
}})
warnings.filterwarnings("ignore")

import re

from nltk.tokenize import word_tokenize
# nltk.download('punkt') # For tokenizing words
# nltk.download('words') # For the list of English words

english_vocab = set(w.lower() for w in nltk.corpus.words.words())

config = configparser.ConfigParser()
config.read('config/config.ini')

# Database Config
BQ_PROJECT = config.get('Database', 'bigquery_project')
BQ_DATASET = config.get('Database', 'bigquery_dataset')
BQ_SERVICE_ACCOUNT_FILE_PATH = config.get('Database', 'service_account_file')

# OpenAI Config
OPENAI_BASE_URL=config.get('OpenAI', 'base_url')
OPENAI_PROJECT_ID=config.get('OpenAI', 'project_id')
OPENAI_API_KEY=config.get('OpenAI', 'api_key')
OPENAI_MODEL=config.get('OpenAI', 'model')
# Create a custom httpx client with SSL verification disabled
custom_http_client = httpx.Client(verify=False)


def is_valid_english(sentence):
    words = word_tokenize(sentence) # Tokenize the sentence into words
    return all(word.lower() in english_vocab or not word.isalpha() for word in words) # Check if all words are English

def normalize_sql(query):
    """Normalize SQL query by formatting and stripping extra spaces."""
    formatter_query =  sqlparse.format(query, strip_comments=True, keyword_case='upper')
    return " ".join(formatter_query.split())

def remove_numbers_and_dots(s):
    # This pattern matches all digits and periods in the string
    return re.sub(r'[\d\.]+', '', s)

@app.route('/health')
def health():
    return "Hello World!"

@app.route('/')
def index():
    return render_template('index.html')

@app.errorhandler(HTTPException)
def handle_exception(e):
    """Return JSON instead of HTML for HTTP errors."""
    response = e.get_response()
    response.data = json.dumps({
        "code": e.code,
        "name": e.name,
        "description": e.description,
    })
    response.content_type = "application/json"
    return response

def get_sql_based_on_llm(query, llm_type):
    
    if llm_type =='openai': 
        sql_query, sql_query_optimised, columns, tables = get_sql_query_openai(query,llm_type)
        
    return sql_query, sql_query_optimised, columns, tables

def generate_sql_based_on_llm(query, llm_type):
    
    if llm_type =='openai': 
        sql_query, columns, tables = get_unoptimised_sql_query_openai(query,llm_type)
        
    return sql_query, columns, tables

def generate_optimised_sql_based_on_llm(query, llm_type):
    
    if llm_type =='openai': 
        sql_query, columns, tables = get_optimised_sql_query_openai(query,llm_type)
    return sql_query, columns, tables

@app.route('/generate_query',methods=["POST"])
def generate_query():
    query = request.json["query"]
    
    print("----User Query-----\n", query)
    llm_type = request.json["llm_type"]
    llm_type = 'openai'
    
    invalid_utterances = ['hi', 'hello', "hey", "good morning", "morning", "good", "how are you?", "how are you", "how is it going", ""]
    query_lowercased = query.lower()
    if query_lowercased in invalid_utterances:
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    query_words = query.split(" ")
    validity=query_words[0].lower()
    if validity not in english_vocab:
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry I didn't get you. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    prompt = get_prompt_for_analytical_intent(query)
    messages = [{"role": "user", "content": f"{prompt}"}]
    answer1 = prompt_llm(messages)
    print("response from validation agent", answer1)
    
    # if answer1 == 'False':
    #     return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}

    print("---Start SQL Query Generation--\n")
    sql_query, columns, tables = generate_sql_based_on_llm(query, llm_type)
    print("---SQL Query Generated--\n", sql_query)

    if "DELETE" in sql_query.upper().split(" ") or "TRUNCATE" in sql_query.upper().split(" ") or "UPDATE" in sql_query.upper().split(" "):
        return {'result': [],'metadata': "", 'sql_query_generated':"",'textual_summary':["Action not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    sql_injection_prompt = get_sql_injection_prompt(sql_query)
    answer2 = prompt_llm([{"role": "user", "content": f"{sql_injection_prompt}"}])
    print("response from sql injection validation agent", answer2)

    if answer2 == 'True':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["SQL Injection detected in the Query. Aborting execution !!"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    ans = {'sql_query_generated': sql_query}

    print(ans)

    return json.dumps(ans, default=str)

@app.route('/generate_insights',methods=["POST"])
def generate_sql_insights():
    query = request.json["query"]
    
    print("----User Query-----\n", query)
    llm_type = request.json["llm_type"]
    llm_type = 'openai'
    
    invalid_utterances = ['hi', 'hello', "hey", "good morning", "morning", "good", "how are you?", "how are you", "how is it going", ""]
    query_lowercased = query.lower()
    if query_lowercased in invalid_utterances:
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    query_words = query.split(" ")
    validity=query_words[0].lower()
    if validity not in english_vocab:
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry I didn't get you. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    prompt = get_prompt_for_analytical_intent(query)
    answer = prompt_llm([{"role": "user", "content": f"{prompt}"}])
    print("response from validation agent", answer)
    
    # if answer == 'False': 
    #     return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}
    
   
    sql_query, sql_query_optimised, columns, tables = get_sql_based_on_llm(query, llm_type)
    
    print("---SQL Query Generated--\n", sql_query)
    print("---SQL Query Optimised--\n", sql_query_optimised)
    
    if ("DELETE" in sql_query.upper().split(" ") or "TRUNCATE" in sql_query.upper().split(" ") or "UPDATE" in sql_query.upper().split(" ") or
            "DELETE" in sql_query_optimised.upper().split(" ") or "TRUNCATE" in sql_query_optimised.upper().split(" ") or "UPDATE" in sql_query_optimised.upper().split(" ")):
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry action not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    sql_injection_prompt = get_sql_injection_prompt(sql_query)
    answer2 = prompt_llm([{"role": "user", "content": f"{sql_injection_prompt}"}])
    print("response from sql injection validation agent", answer2)

    if answer2 == 'True':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["SQL Injection detected in the Query. Aborting execution !!"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    # Custom connection details for BigQuery
    job_config = bigquery.QueryJobConfig(default_dataset=BQ_PROJECT + "." + BQ_DATASET)
    credentials = service_account.Credentials.from_service_account_file(
        BQ_SERVICE_ACCOUNT_FILE_PATH
    )
    bq = bigquery.Client(credentials=credentials, project=BQ_PROJECT)
    
    try:
        try:
            try:

                df = bq.query(sql_query_optimised, job_config).to_dataframe()
                print(df)

            except Exception as e:

                print(e)

                prompt = f'''While running following query:-

                {sql_query_optimised} for following user query, tables and column names:

                User query: {query}
                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {e}

                Please fix the Big query SQL based on the above error and reshare?
                Note: Just print the fixed SQL query and nothing else.

                '''
                sql_query, sql_query_optimised, columns, tables = get_sql_based_on_llm(prompt, llm_type='openai')

                print('Output', sql_query_optimised)

                df = bq.query(sql_query_optimised, job_config).to_dataframe()

        except Exception as f:
            
            print(f)

            prompt = f'''While running following query:-

                {sql_query_optimised} for following user query, tables and column names:

                User query: {query}
                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {f}

                Please fix the Big query SQL based on the above error and reshare?
                Note: Just print the fixed SQL query and nothing else.

                '''
            sql_query, sql_query_optimised, columns, tables = get_sql_based_on_llm(prompt, llm_type='openai')

            print('Output', sql_query_optimised)

            df = bq.query(sql_query_optimised,job_config).to_dataframe()
        
    except Exception as g:
        
        print(g)
        
        fixed_input_query_prompt =  f'''While running following sql query:-

                {sql_query_optimised} for following tables and column names:

                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {g}
                
                for the user query:-
                
                User Query: {query}

                Can you rephrase the above user query so that it generates the correct SQL with good execution accuracy?
                Just print the rephrased user query and nothing else?

                '''
        message_prompt = [{"role": "user", "content": f"{fixed_input_query_prompt}"}]
        rephrased_query = prompt_llm(message_prompt)
        
        print("Rephrased query ", rephrased_query)
        
        return {'result': [],'metadata': "", 'sql_query':"Not a valid SQL query",'textual_summary':["Sorry I didn't get it. Could you please try again by modifying the query?"], 'followup_prompts':[rephrased_query + '?'],"x-axis":"", "typeOFgraph":""}
    
    try:       
        for column in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[column]):
                # Handle NaN for datetime columns (e.g., fill with a specific date)
                df[column].fillna(pd.Timestamp('2021-01-01'), inplace=True)
            elif pd.api.types.is_float_dtype(df[column]):
                # Handle NaN for float columns (e.g., fill with mean of the column)
                df[column].fillna(0.0, inplace=True)
            elif pd.api.types.is_string_dtype(df[column]):
                # Handle NaN for string columns (e.g., fill with a placeholder string)
                df[column].fillna('unknown', inplace=True)
            elif pd.api.types.is_integer_dtype(df[column]):
                # Handle NaN for integer columns (e.g., convert to nullable integer and fill with a placeholder)
                df[column].fillna(0, inplace=True)

        for column in df.columns:
            if df[column].dtype == float:
                # df[column].fillna(value=0, inplace=True)
                df[column] = df[column].round(2)


        def is_datetime(column):
            # return pd.api.types.is_datetime64_ns_dtype(column.dtype)
            return pd.api.types.is_datetime64_any_dtype(column)

        for column in df.columns:

            if is_datetime(df[column]):

                # df[column].fillna(value=0, inplace=True)
                df[column] = pd.to_datetime(df[column], errors='coerce').dt.strftime('%Y-%m-%d')


        result = df.to_dict(orient = 'records')

        columns = df.columns.values.tolist() 
        md_map = df.dtypes.to_dict()

        var_prompt = f"""Here is an sql query: {sql_query_optimised}, i will run this on the table with the schema: {md_map} and further i would also want to visualize the results. I want you to give me the X-axis for the graph i will plot by analyzing the columns asked in the query . Only use the column names given in the schema below and dont change them. Just give the column name, i dont want any explanation.
        IMPORTANT: If the generated columns: {columns} are not in the schema, just return the independent variable from the list of columns {columns}.
        IMPORTANT: I want to use your output directly in my server so it very important you just give me the column_name according to the schema and no additional details given, not even a statement required, just the column_name as the output is required. Make sure you only give one coumn as x axis and not multiple. And just the column name is required. """

        graph_prompt=f""" Imagine you are a data analyst and you were asked to plot a graph for the following data dictionary
        :
        {result[0]}

        Following is the datatype of the columns of the dataframe:-

        {md_map}

        Which was generated by the following business query: 
        {query}

        What kind of graph do you think would be best for visualization for Business Insight among 'Line' and 'Bar' based on above business query and columns data type.Use the standard conventions for the type of graph name.
        Note: Just print the type of graph(Line or Bar) and nothing else.
        """
        describe_prompt = f"""Assume you are a data analyst look into these values generated for my question which was '{query}' and give me only top 3 insights of this data in bullet points on seperate lines . values:{df.to_dict()}, metadeta:{md_map}. For these insights, do trend analysis if trend is present in data. Point out anomalies if present in the data and try to provide reason. Do root cause analysis for trends and anomalies. But also add further research and analyis needed to validate. Also, if customer segments are present, try to give insight on that as well.
        Note:- Just print the insights in separate new lines (\n) without bullets and nothing else
        If the numbers in the output insights summary are too large, then reformat it in MM (for millions),K (for thousands) and B (for billions).
        """

        textual_summaries = describe_bot(describe_prompt, llm_type='openai')

        textual_summaries = textual_summaries.replace("'", "").replace("**", "").replace("#", "")

        # x_axis = describe_bot(var_prompt, llm_type='openai')

        # typeOfGraph = describe_bot(graph_prompt,llm_type='openai')

        sql_query_optimised = sql_query_optimised.replace('\n', '')
        # sql_query_optimised = sql_query_optimised.replace("'", "")
        textual_summary = textual_summaries.split('\n')

        if len(textual_summary)> 0:
            summaries=[]
            for summary_bullet in textual_summary:
                if len(summary_bullet.split(" ")) > 6:
                    summaries.append(summary_bullet.strip(' *').replace("**", "").replace("#", ""))          
        else:
             summaries=["No summary generated"]

        prompts = sample_gen(df,query, tables, columns, llm_type)
        prompts= prompts.replace("'", "").replace("**", "").replace("#", "")
        sample_prompts = []
        prompts_lst = prompts.split('\n')

        if len(prompts_lst) > 0:
            for i, prompt in enumerate(prompts.split('\n')):
                if len(prompt.split(" ")) > 5:
                    prompt = remove_numbers_and_dots(prompt)
                    sample_prompts.append(prompt.strip('* '))         
        else:
             sample_prompts = ["No follow up prompts"]

        # if len(x_axis.split(' ')) > 1:

        # for col in df.columns:

        #     if df[col].nunique() > 1:

        #         x_axis = col
        #         break

        # print("X axis", x_axis)

        # metadata={'columns':columns, 'x_axis':x_axis}

        ans = {'result': result,'metadata':"", 'sql_query_generated':sql_query, 'sql_query_optimised':sql_query_optimised,'textual_summary':summaries, 'followup_prompts':sample_prompts,"x-axis":"", "typeOFgraph":""}

        print(ans)

        return json.dumps(ans, default=str)
    
    except Exception as err:
        
        print(err)
        
        return {'result': [],'metadata': "", 'sql_query_generated':sql_query, 'sql_query_optimised':sql_query_optimised,'textual_summary':["No data available for Insights"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}

@app.route('/optimise_query',methods=["POST"])
def optimise_query():
    query = request.json["query"]
    
    print("----User SQL Query-----\n", query)
    llm_type = request.json["llm_type"]
    llm_type = 'openai'
    
    invalid_utterances = ['hi', 'hello', "hey", "good morning", "morning", "good", "how are you?", "how are you", "how is it going", ""]
    query_lowercased = query.lower()
    if query_lowercased in invalid_utterances:
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    prompt = get_prompt_for_sql_query_verification(query)
    answer = prompt_llm([{"role": "user", "content": f"{prompt}"}])
    print("Is SQL Query? Response from validation agent:", answer)
    
    if answer == 'False':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid SQL query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    sql_injection_prompt = get_sql_injection_prompt(query)
    answer2 = prompt_llm([{"role": "user", "content": f"{sql_injection_prompt}"}])
    print("response from sql injection validation agent", answer2)
    if answer2 == 'True':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["SQL Injection detected in the Query. Aborting execution !!"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    # Check sample DMA query
    normalized_query = normalize_sql(query)
    alternative_query = SAMPLE_QUERY.get(normalized_query, "No alternative query found")
    print(f"Normalized Input Query: {normalized_query}")
    print(alternative_query)
    if alternative_query != 'No alternative query found':
        time.sleep(5)  # Delay response by 5 seconds
        return {'sql_query_generated': alternative_query}

    sql_query, columns, tables = generate_optimised_sql_based_on_llm(query, llm_type)
    
    print("---[Optimised] SQL Query Generated--\n", sql_query)

    if "DELETE" in sql_query.upper().split(" ") or "TRUNCATE" in sql_query.upper().split(" ") or "UPDATE" in sql_query.upper().split(" "):
        return {'result': [],'metadata': "", 'sql_query_generated':"",'textual_summary':["Sorry this action is not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    ans = {'sql_query_generated': sql_query}
    print(ans)

    return json.dumps(ans, default=str)
        
@app.route('/generate_insights_from_query',methods=["POST"])
def generate_insights_from_query():
    query = request.json["query"]
    
    print("----User Query-----\n", query)
    llm_type = request.json["llm_type"]
    llm_type = 'openai'
    
    invalid_utterances = ['hi', 'hello', "hey", "good morning", "morning", "good", "how are you?", "how are you", "how is it going", ""]
    query_lowercased = query.lower()
    if query_lowercased in invalid_utterances:
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid SQL query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    prompt = get_prompt_for_sql_query_verification(query)
    answer = prompt_llm([{"role": "user", "content": f"{prompt}"}])
    print("response from validation agent", answer)
    
    if answer == 'False':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid SQL query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    sql_query, columns, tables = generate_optimised_sql_based_on_llm(query, llm_type)
    
    if "DELETE" in query.upper().split(" ") or "TRUNCATE" in sql_query.upper().split(" ") or "UPDATE" in query.upper().split(" "):
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid SQL query. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    sql_injection_prompt = get_sql_injection_prompt(sql_query)
    answer2 = prompt_llm([{"role": "user", "content": f"{sql_injection_prompt}"}])
    print("response from sql injection validation agent", answer2)

    if answer2 == 'True':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["SQL Injection detected in the Query. Aborting execution !!"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    # Custom connection details for BigQuery
    job_config = bigquery.QueryJobConfig(default_dataset=BQ_PROJECT + "." + BQ_DATASET)
    credentials = service_account.Credentials.from_service_account_file(
        BQ_SERVICE_ACCOUNT_FILE_PATH
    )
    bq = bigquery.Client(credentials=credentials, project=BQ_PROJECT)
    
    try:
        try:
            try:

                df = bq.query(query, job_config).to_dataframe()

            except Exception as e:

                print(e)

                prompt = f'''While running following query:-

                {query} for following user query, tables and column names:

                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {e}

                Please fix the Big query SQL based on the above error and reshare?
                Note: Just print the fixed SQL query and nothing else.

                '''
                query, columns, tables = generate_optimised_sql_based_on_llm(prompt, llm_type='openai')

                print('Output', query)

                df = bq.query(query, job_config).to_dataframe()

        except Exception as f:
            
            print(f)

            prompt = f'''While running following query:-

                {query} for following user query, tables and column names:

                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {f}

                Please fix the Big query SQL based on the above error and reshare?
                Note: Just print the fixed SQL query and nothing else.

                '''
            query, columns, tables = generate_optimised_sql_based_on_llm(prompt, llm_type='openai')

            print('Output', query)

            df = bq.query(query,job_config).to_dataframe()
        
    except Exception as g:
        
        print(g)
        
        fixed_input_query_prompt =  f'''While running following sql query:-

                {query} for following tables and column names:

                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {g}
                
                for the user query:-
                
                User Query: {query}

                Can you rephrase the above user query so that it generates the correct SQL with good execution accuracy?
                Just print the rephrased user query and nothing else?

                '''
        message_prompt = [{"role": "user", "content": f"{fixed_input_query_prompt}"}]
        rephrased_query = prompt_llm(message_prompt)

        print("Rephrased query ", rephrased_query)
        
        return {'result': [],'metadata': "", 'sql_query':"Not a valid SQL query",'textual_summary':["Sorry I didn't get it. Could you please try again by modifying the query?"], 'followup_prompts':[rephrased_query + '?'],"x-axis":"", "typeOFgraph":""}
    
    try:       
        for column in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[column]):
                # Handle NaN for datetime columns (e.g., fill with a specific date)
                df[column].fillna(pd.Timestamp('2021-01-01'), inplace=True)
            elif pd.api.types.is_float_dtype(df[column]):
                # Handle NaN for float columns (e.g., fill with mean of the column)
                df[column].fillna(0.0, inplace=True)
            elif pd.api.types.is_string_dtype(df[column]):
                # Handle NaN for string columns (e.g., fill with a placeholder string)
                df[column].fillna('unknown', inplace=True)
            elif pd.api.types.is_integer_dtype(df[column]):
                # Handle NaN for integer columns (e.g., convert to nullable integer and fill with a placeholder)
                df[column].fillna(0, inplace=True)

        for column in df.columns:
            if df[column].dtype == float:
                # df[column].fillna(value=0, inplace=True)
                df[column] = df[column].round(2)


        def is_datetime(column):
            # return pd.api.types.is_datetime64_ns_dtype(column.dtype)
            return pd.api.types.is_datetime64_any_dtype(column)

        for column in df.columns:

            if is_datetime(df[column]):

                # df[column].fillna(value=0, inplace=True)
                df[column] = pd.to_datetime(df[column], errors='coerce').dt.strftime('%Y-%m-%d')


        result = df.to_dict(orient = 'records')

        columns = df.columns.values.tolist() 
        md_map = df.dtypes.to_dict()

        var_prompt = f"""Here is an sql query: {query}, i will run this on the table with the schema: {md_map} and further i would also want to visualize the results. I want you to give me the X-axis for the graph i will plot by analyzing the columns asked in the query . Only use the column names given in the schema below and dont change them. Just give the column name, i dont want any explanation.
        IMPORTANT: If the generated columns: {columns} are not in the schema, just return the independent variable from the list of columns {columns}.
        IMPORTANT: I want to use your output directly in my server so it very important you just give me the column_name according to the schema and no additional details given, not even a statement required, just the column_name as the output is required. Make sure you only give one coumn as x axis and not multiple. And just the column name is required. """

        graph_prompt=f""" Imagine you are a data analyst and you were asked to plot a graph for the following data dictionary
        :
        {result[0]}

        Following is the datatype of the columns of the dataframe:-

        {md_map}

        Which was generated by the following SQL query: 
        {query}

        What kind of graph do you think would be best for visualization for Business Insight among 'Line' and 'Bar' based on above business query and columns data type.Use the standard conventions for the type of graph name.
        Note: Just print the type of graph(Line or Bar) and nothing else.
        """
        describe_prompt = f"""Assume you are a data analyst look into these values generated for my SQL Query which was '{query}' and give me only top 3 insights of this data in bullet points on seperate lines . values:{df.to_dict()}, metadeta:{md_map}. For these insights, do trend analysis if trend is present in data. Point out anomalies if present in the data and try to provide reason. Do root cause analysis for trends and anomalies. But also add further research and analyis needed to validate. Also, if customer segments are present, try to give insight on that as well.
        Note:- Just print the insights in separate new lines (\n) without bullets and nothing else
        If the numbers in the output insights summary are too large, then reformat it in MM (for millions),K (for thousands) and B (for billions).
        """

        textual_summaries = describe_bot(describe_prompt, llm_type='openai')

        textual_summaries = textual_summaries.replace("'", "").replace("**", "").replace("#", "")

        # x_axis = describe_bot(var_prompt, llm_type='openai')

        # typeOfGraph = describe_bot(graph_prompt,llm_type='openai')

        query = query.replace('\n', '')
        # sql_query_optimised = sql_query_optimised.replace("'", "")
        textual_summary = textual_summaries.split('\n')

        if len(textual_summary)> 0:
            summaries=[]
            for summary_bullet in textual_summary:
                if len(summary_bullet.split(" ")) > 6:
                    summaries.append(summary_bullet.strip(' *').replace("**", "").replace("#", ""))          
        else:
             summaries=["No summary generated"]

        # for col in df.columns:

        #     if df[col].nunique() > 1:

        #         x_axis = col
        #         break

        # metadata={'columns':columns, 'x_axis':x_axis}

        ans = {'result': result,'metadata':"", 'sql_query_generated':query, 'textual_summary':summaries, 'followup_prompts':[], "x-axis":"", "typeOFgraph":""}
        print(ans)
        return json.dumps(ans, default=str)
    
    except Exception as err:
        print(err)
        return {'result': [],'metadata': "", 'sql_query_generated':query, 'textual_summary':["No data available for Insights"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}

@app.route('/generate_insights_from_nl_query',methods=["POST"])
def generate_insights_from_nl_query():
    query = request.json["query"]
    bq_query = request.json["bq_query"]
    print("----User Query-----\n", query)
    llm_type = request.json["llm_type"]
    llm_type = 'openai'
    
    sql_query = bq_query
    
    if ("DELETE" in sql_query.upper().split(" ") or "TRUNCATE" in sql_query.upper().split(" ") or "UPDATE" in sql_query.upper().split(" ")):
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry action not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    prompt = get_prompt_for_sql_query_verification(sql_query)
    answer = prompt_llm([{"role": "user", "content": f"{prompt}"}])
    print("Is SQL Query? Response from validation agent:", answer)
    
    if answer == 'False':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["Sorry not a valid SQL query. Could you please try again?"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400
    
    sql_injection_prompt = get_sql_injection_prompt(sql_query)
    answer2 = prompt_llm([{"role": "user", "content": f"{sql_injection_prompt}"}])
    print("response from sql injection validation agent", answer2)

    if answer2 == 'True':
        return {'result': [],'metadata': "", 'sql_query':"",'textual_summary':["SQL Injection detected in the Query. Aborting execution !!"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}, 400

    columns = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    # Custom connection details for BigQuery
    job_config = bigquery.QueryJobConfig(default_dataset=BQ_PROJECT + "." + BQ_DATASET)
    credentials = service_account.Credentials.from_service_account_file(
        BQ_SERVICE_ACCOUNT_FILE_PATH
    )
    bq = bigquery.Client(credentials=credentials, project=BQ_PROJECT)
    
    try:
        try:
            try:

                df = bq.query(sql_query, job_config).to_dataframe()
                print(df)

            except Exception as e:

                print(e)

                prompt = f'''While running following query:-

                {sql_query} for following user query, tables and column names:

                User query: {query}
                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {e}

                Please fix the Big query SQL based on the above error and reshare?
                Note: Just print the fixed SQL query and nothing else.

                '''
                sql_query, sql_query_optimised, columns, tables = get_sql_based_on_llm(prompt, llm_type='openai')

                print('Output', sql_query_optimised)

                df = bq.query(sql_query_optimised, job_config).to_dataframe()

        except Exception as f:
            
            print(f)

            prompt = f'''While running following query:-

                {sql_query} for following user query, tables and column names:

                User query: {query}
                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {f}

                Please fix the Big query SQL based on the above error and reshare?
                Note: Just print the fixed SQL query and nothing else.

                '''
            sql_query, sql_query_optimised, columns, tables = get_sql_based_on_llm(prompt, llm_type='openai')

            print('Output', sql_query_optimised)

            df = bq.query(sql_query_optimised,job_config).to_dataframe()
        
    except Exception as g:
        
        print(g)
        
        fixed_input_query_prompt =  f'''While running following sql query:-

                {sql_query} for following tables and column names:

                Tables: {tables}
                Columns: {columns}

                I am getting following error:-

                {g}
                
                for the user query:-
                
                User Query: {query}

                Can you rephrase the above user query so that it generates the correct SQL with good execution accuracy?
                Just print the rephrased user query and nothing else?

                '''
        message_prompt = [{"role": "user", "content": f"{fixed_input_query_prompt}"}]
        rephrased_query = prompt_llm(message_prompt)
        
        print("Rephrased query ", rephrased_query)
        
        return {'result': [],'metadata': "", 'sql_query':"Not a valid SQL query",'textual_summary':["Sorry I didn't get it. Could you please try again by modifying the query?"], 'followup_prompts':[rephrased_query + '?'],"x-axis":"", "typeOFgraph":""}
    
    try:       
        for column in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[column]):
                # Handle NaN for datetime columns (e.g., fill with a specific date)
                df[column].fillna(pd.Timestamp('2021-01-01'), inplace=True)
            elif pd.api.types.is_float_dtype(df[column]):
                # Handle NaN for float columns (e.g., fill with mean of the column)
                df[column].fillna(0.0, inplace=True)
            elif pd.api.types.is_string_dtype(df[column]):
                # Handle NaN for string columns (e.g., fill with a placeholder string)
                df[column].fillna('unknown', inplace=True)
            elif pd.api.types.is_integer_dtype(df[column]):
                # Handle NaN for integer columns (e.g., convert to nullable integer and fill with a placeholder)
                df[column].fillna(0, inplace=True)

        for column in df.columns:
            if df[column].dtype == float:
                # df[column].fillna(value=0, inplace=True)
                df[column] = df[column].round(2)


        def is_datetime(column):
            # return pd.api.types.is_datetime64_ns_dtype(column.dtype)
            return pd.api.types.is_datetime64_any_dtype(column)

        for column in df.columns:

            if is_datetime(df[column]):

                # df[column].fillna(value=0, inplace=True)
                df[column] = pd.to_datetime(df[column], errors='coerce').dt.strftime('%Y-%m-%d')


        result = df.to_dict(orient = 'records')

        columns = df.columns.values.tolist() 
        md_map = df.dtypes.to_dict()

        # var_prompt = f"""Here is an sql query: {sql_query}, i will run this on the table with the schema: {md_map} and further i would also want to visualize the results. I want you to give me the X-axis for the graph i will plot by analyzing the columns asked in the query . Only use the column names given in the schema below and dont change them. Just give the column name, i dont want any explanation.
        # IMPORTANT: If the generated columns: {columns} are not in the schema, just return the independent variable from the list of columns {columns}.
        # IMPORTANT: I want to use your output directly in my server so it very important you just give me the column_name according to the schema and no additional details given, not even a statement required, just the column_name as the output is required. Make sure you only give one coumn as x axis and not multiple. And just the column name is required. """

        # graph_prompt=f""" Imagine you are a data analyst and you were asked to plot a graph for the following data dictionary
        # :
        # {result[0]}

        # Following is the datatype of the columns of the dataframe:-

        # {md_map}

        # Which was generated by the following business query: 
        # {query}

        # What kind of graph do you think would be best for visualization for Business Insight among 'Line' and 'Bar' based on above business query and columns data type.Use the standard conventions for the type of graph name.
        # Note: Just print the type of graph(Line or Bar) and nothing else.
        # """
        describe_prompt = f"""Assume you are a data analyst look into these values generated for my question which was '{query}' and give me only top 3 insights of this data in bullet points on seperate lines . values:{df.to_dict()}, metadeta:{md_map}. For these insights, do trend analysis if trend is present in data. Point out anomalies if present in the data and try to provide reason. Do root cause analysis for trends and anomalies. But also add further research and analyis needed to validate. Also, if customer segments are present, try to give insight on that as well.
        Note:- Just print the insights in separate new lines (\n) without bullets and nothing else
        If the numbers in the output insights summary are too large, then reformat it in MM (for millions),K (for thousands) and B (for billions).
        """

        textual_summaries = describe_bot(describe_prompt, llm_type='openai')

        textual_summaries = textual_summaries.replace("'", "").replace("**", "").replace("#", "")

        # x_axis = describe_bot(var_prompt, llm_type='openai')

        # typeOfGraph = describe_bot(graph_prompt,llm_type='openai')

        sql_query = sql_query.replace('\n', '')
        # sql_query_optimised = sql_query_optimised.replace("'", "")
        textual_summary = textual_summaries.split('\n')

        if len(textual_summary)> 0:
            summaries=[]
            for summary_bullet in textual_summary:
                if len(summary_bullet.split(" ")) > 6:
                    summaries.append(summary_bullet.strip(' *').replace("**", "").replace("#", ""))          
        else:
             summaries=["No summary generated"]

        prompts = sample_gen(df,query, tables, columns, llm_type)
        prompts= prompts.replace("'", "").replace("**", "").replace("#", "")
        sample_prompts = []
        prompts_lst = prompts.split('\n')

        if len(prompts_lst) > 0:
            for i, prompt in enumerate(prompts.split('\n')):
                if len(prompt.split(" ")) > 5:
                    prompt = remove_numbers_and_dots(prompt)
                    sample_prompts.append(prompt.strip('* '))         
        else:
             sample_prompts = ["No follow up prompts"]

        # if len(x_axis.split(' ')) > 1:

        # for col in df.columns:

        #     if df[col].nunique() > 1:

        #         x_axis = col
        #         break

        # print("X axis", x_axis)

        # metadata={'columns':columns, 'x_axis':x_axis}

        ans = {'result': result,'metadata':"", 'sql_query_generated':sql_query, 'sql_query_optimised':sql_query,'textual_summary':summaries, 'followup_prompts':sample_prompts,"x-axis":"", "typeOFgraph":""}

        print(ans)

        return json.dumps(ans, default=str)
    
    except Exception as err:
        
        print(err)
        
        return {'result': [],'metadata': "", 'sql_query_generated':sql_query, 'sql_query_optimised':sql_query,'textual_summary':["No data available for Insights"], 'followup_prompts':[],"x-axis":"", "typeOFgraph":""}

def main():
    app.run(host='0.0.0.0', port=8082, debug = True)

if __name__ == "__main__":
    main()
