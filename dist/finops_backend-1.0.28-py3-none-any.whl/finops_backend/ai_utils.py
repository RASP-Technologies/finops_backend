from langchain.document_loaders import CSVLoader, PyPDFLoader, Docx2txtLoader, UnstructuredExcelLoader, WebBaseLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain import PromptTemplate
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings, VertexAIEmbeddings
from google.cloud import aiplatform
from vertexai.preview.language_models import TextEmbeddingModel
from langchain.chat_models import ChatOpenAI
from langchain.llms import VertexAI
from langchain.chains.question_answering import load_qa_chain
from langchain.chains import RetrievalQA
from langchain.memory import ConversationBufferMemory
from langchain.schema.runnable import RunnablePassthrough
from langchain import hub
import time
import pickle
import os
import vertexai
from vertexai.language_models import CodeGenerationModel
from vertexai.preview.language_models import TextGenerationModel
from vertexai.preview.generative_models import GenerativeModel
# import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import openai
from langchain import PromptTemplate, LLMChain
from langchain.chat_models import ChatOpenAI
from langchain.chat_models import ChatVertexAI
import argparse
from langchain.embeddings import VertexAIEmbeddings
from langchain.document_loaders import JSONLoader
from langchain.embeddings.base import Embeddings
from langchain.vectorstores import FAISS
from google.cloud import bigquery
from typing import List
from tqdm import tqdm
import logging
import json
import os 
import sys
from openai import OpenAI
# from langchain.llms import OpenAI
import plotly.express as px
import streamlit as st
from langchain.prompts.chat import SystemMessagePromptTemplate
from langchain.prompts.chat import HumanMessagePromptTemplate
from langchain.prompts.chat import AIMessagePromptTemplate
from langchain.prompts.chat import ChatPromptTemplate
from vertexai.preview.generative_models import GenerativeModel
from langchain.callbacks.manager import CallbackManager
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.llms import LlamaCpp
import configparser
import httpx
import requests
from langchain_openai import AzureOpenAIEmbeddings


config = configparser.ConfigParser()
config.read('config/config.ini')
os.environ['SSL_CERT_FILE']=config.get('OpenAI', 'cert_path')
os.environ['TIKTOKEN_CACHE_DIR']=config.get('OpenAI', 'TIKTOKEN_CACHE_DIR')

# Database Config
BQ_PROJECT = config.get('Database', 'bigquery_project')
BQ_DATASET = config.get('Database', 'bigquery_dataset')
BQ_SERVICE_ACCOUNT_FILE_PATH = config.get('Database', 'service_account_file')
DB_COLUMN_PATH = config.get('Database', 'columns_path')
DB_TABLES_PATH = config.get('Database', 'tables_path')

# OpenAI Config
OPENAI_BASE_URL=config.get('OpenAI', 'base_url')
OPENAI_BASE_EMBEDDING_URL=config.get('OpenAI', 'base_embedding_url')
OPENAI_PROJECT_ID=config.get('OpenAI', 'project_id')
OPENAI_API_KEY=config.get('OpenAI', 'api_key')
OPENAI_API_VERSION=config.get('OpenAI', 'api_version')
OPENAI_MODEL=config.get('OpenAI', 'model')
OPENAI_EMBEDDING_MODEL=config.get('OpenAI', 'embedding_model')
# Create a custom httpx client with SSL verification disabled
custom_http_client = httpx.Client(verify=False)
custom_http_client_embedded = httpx.AsyncClient(verify=False)


# -------------------------------------------------------------------------------

os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
openai_api_key = os.environ.get('OPENAI_API_KEY')

# -------------------------------------------------------------------------------


messages = []
#vertex_template = "You are a SQL master expert capable of writing complex SQL query in Bigquery. write query in  GoogleSQL dialect or legacy SQL dialect"
vertex_template = "You are a Bigquery expert capable of writing complex SQL query in Bigquery. Use only  bigquery  native functions and construct"
system_message_prompt = SystemMessagePromptTemplate.from_template(vertex_template)
messages.append(system_message_prompt)
human_template = """Given the following inputs:
----
USER_QUERY:{query}
---
TABLES : {matched_tables}
---
MATCHED_SCHEMA: {matched_schema}
------
IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA with the table_name. DO NOT USE any other column names outside of this. 
IMPORTANT: Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA
IMPORTANT: avoid using alias column in where clause . 
IMPORTANT: use safe divide , safe cast where ever possible
"""
human_message = HumanMessagePromptTemplate.from_template(human_template)
messages.append(human_message)
vertex_prompt = ChatPromptTemplate.from_messages(messages)

#--------------------------------------
gemini_prompt="""
"You are a Bigquery expert capable of writing complex SQL query in Bigquery. Use only  bigquery  native functions and constructs.
--- given the table details with their description and columns used for joins . which are '|' seperated .
``
TABLES : {matched_tables}
``
---
given the column details, description and usage which are '|' seperated as following . 
```
MATCHED_SCHEMA: {matched_schema}


```
Write a GoogleSQL dialect SQL using the above column details and tables provided in details which achieves the following.
```
{content}
```
IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA. DO NOT USE any other column names outside of this. 
IMPORTANT: Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA.
Note: Use SAFE_DIVIDE, SAFE_CAST wherever possible. Instead of using strftime(), use BigQuery native functions like EXTRACT(YEAR FROM date_column) and EXTRACT(MONTH FROM date_column) for date handling. Avoid using alias names in GROUP BY and ORDER BY sections. 
IMPORTANT: Avoid GCP Project ID and Dataset reference in the output SQL.
"""

# -------------------------------------------------------------------------------

# class MyVertexAIEmbeddings(OpenAIEmbeddings, Embeddings):

#     model_name = 'textembedding-gecko'
#     max_batch_size = 5

# # -------------------------------------------------------------------------------

#     def embed_segments(self, segments: List) -> List:
#         embeddings = []
#         for i in tqdm(range(0, len(segments), self.max_batch_size)):
#             batch = segments[i: i+self.max_batch_size]
#             embeddings.extend(self.client.get_embeddings(batch))
#         return [embedding.values for embedding in embeddings]


# # -------------------------------------------------------------------------------

#     def embed_query(self, query: str) -> List:
#         embeddings = self.client.get_embeddings([query])
#         return embeddings[0].values
if OPENAI_BASE_EMBEDDING_URL:
    # embedding = OpenAIEmbeddings(
    # base_url=OPENAI_BASE_EMBEDDING_URL,
    # model=OPENAI_EMBEDDING_MODEL,
    # default_headers={
    #         'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
    #         'Authorization-Type': 'genai',
    #         'Authorization': f'Bearer {OPENAI_API_KEY}',
    #         "Content-Type": "application/json"
    #     },
    # async_client=custom_http_client_embedded
    # # With the `text-embedding-3` class
    # of models, you can specify the size
    # of the embeddings you want returned.
    # dimensions=1024
    # )
    print("start call for embedding\n")
    headers = {
        'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"embedding"}}',
        'Authorization-Type': 'genai',
        'Authorization': f'Bearer {OPENAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    embedding = AzureOpenAIEmbeddings(azure_endpoint=OPENAI_BASE_EMBEDDING_URL,
                                     openai_api_key=OPENAI_API_KEY,
                                     openai_api_version=OPENAI_API_VERSION,
                                     deployment=OPENAI_EMBEDDING_MODEL,
                                     default_headers=headers)


else:
    embedding = OpenAIEmbeddings(
    model=OPENAI_EMBEDDING_MODEL
    # With the `text-embedding-3` class
    # of models, you can specify the size
    # of the embeddings you want returned.
    # dimensions=1024
    )

# -------------------------------------------------------------------------------    

def llama_init():
    n_gpu_layers = 1  # Metal set to 1 is enough.
    n_batch = 1024  # Should be between 1 and n_ctx, consider the amount of RAM of your Apple Silicon Chip.
    callback_manager = CallbackManager([StreamingStdOutCallbackHandler()])

    # Make sure the model path is correct for your system!
    llm_llama = LlamaCpp(
        model_path="llama.cpp/models/7B/ggml-model-f16.bin",
        n_gpu_layers=n_gpu_layers,
        n_batch=n_batch,
        n_ctx=4096,
        f16_kv=True,  # MUST set to True, otherwise you will run into problem after a couple of calls
        callback_manager=callback_manager,
        verbose=True,
    )
    return llm_llama

# -------------------------------------------------------------------------------    

def describe_bot(prompt,llm_type):
    if llm_type == "palm2":
        vertexai.init(project="techsteer", location="us-central1")
        parameters = {
            "max_output_tokens": 1024,
            "temperature": 0,
            "top_p": 0.8,
            "top_k": 40
        }
        model = TextGenerationModel.from_pretrained("text-bison@001")
        response = model.predict(
            f"""{prompt}""",
            **parameters
        )
        return response.text
        pass
    
    elif llm_type == 'openai':
        # Initialize OpenAI client with or without base_url
        if OPENAI_BASE_URL:
            client = OpenAI(
                base_url=OPENAI_BASE_URL, 
                default_headers={
                    'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
                    'Authorization-Type': 'genai',
                    'Authorization': f'Bearer {OPENAI_API_KEY}',
                    "Content-Type": "application/json"
                    },
                http_client=custom_http_client
            )

            headers = {
                'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
                'Authorization-Type': 'genai',
                'Authorization': f'Bearer {OPENAI_API_KEY}',
                'Content-Type': 'application/json'
            }

            data = {
                "messages": [{"role": "user", "content": f"{prompt}"}],
                "temperature": 0.0 ,
                "top_p": 0.8,
                "frequency_penalty": 0,
                "presence_penalty": 0,
                "max_tokens": 2919,
                "stop": None,
                "stream": False
            }

            response = requests.post(OPENAI_BASE_URL , headers=headers, json=data, verify=False )
            response = json.loads(response.text)
            answer = response['choices'][0]['message']['content'].strip()

        else:
            client = OpenAI()
            response = client.chat.completions.create(
                model = OPENAI_MODEL,
                messages = [{"role": "system", "content": "You are Business Analyst"},{"role": "user", "content": f"{prompt}"}
                            ],
                temperature = 0.0
            )
            answer = response.choices[0].message.content.strip()

        OpenAI.api_key = os.getenv('OPENAI_API_KEY')
        print("Request URL: ", client.base_url)
        print("Request Headers: ", client.default_headers)
        print("Request Model:", OPENAI_MODEL)

        print("Response:", response)
        return answer
        pass

    elif llm_type == 'gemini-pro':
        MODEL_NAME = 'gemini-pro'
        model = GenerativeModel(MODEL_NAME)
        responses = model.generate_content(
            prompt,
            generation_config={
                "temperature": 0.0,
                "max_output_tokens": 800,
                "top_p": 1.0,
                "top_k": 40,
            },
            stream=False
        )
        response = '\n'.join(responses.text.strip().replace('```sql',' ').replace('```',' ').split('\n'))
        return response
        pass
    elif llm_type == 'llama':
        llm_llama =llama_init()
        # print('reached desc')
        answer = llm_llama(prompt)
        # print('reached desc ans')
        # print(answer)
        return answer
        pass

# -------------------------------------------------------------------------------    

def predict(content: str,schema: str,tables:str,llm):
    verbose: bool = False

    # Load middle conversation from JSON
    with open("config/messages.json", "r") as file:
        middle_conversation = json.load(file)
    
    # Define system instruction
    system_message = {
        "role": "system",
        "content": "You are an Analyst and you are hands-on in BigQuery SQL. Respond only with SQL queries with no explanation."
    }

    
    
    TEMPLATE = f'''
    --- given the table details with description and columns used for joins . which are '|' seperated .
    ``
    TABLES : {tables}
    ``
    ---
    given the column details which are '|' seperated as following . 
    ```
    MATCHED_SCHEMA: {schema}


    ```
    Write an unoptimised GoogleSQL dialect SQL using the above column details and tables provided in details which achieves the following.
    ```
    { content }
    ```
    IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA. DO NOT USE any other column names outside of this. 
    IMPORTANT: `` Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA ``.
    Note : use safe divide , safe cast where ever possible. Avoid using alias names in groupby and orderby sections.
    IMPORTANT: Make sure the generated SQL has consistent spacing and correct formatting.
    IMPORTANT: Avoid GCP Project ID and Dataset reference in the output SQL.
    IMPORTANT: Always make this query deliberately inefficient and should have scope of optimisation.

    '''
    
    # Define the last user prompt dynamically
    last_prompt = {
        "role": "user",
        "content": f"{TEMPLATE}"
    }
    # prompt = PromptTemplate(
    #     input_variables=["content","schema","tables"],
    #     template=TEMPLATE,
    #     template_format='jinja2',
    # )
    
    

    
    # prompt = TEMPLATE.format(content=content, matched_schema=schema, matched_tables=tables)
    
    # print("PromptTemplate: ", TEMPLATE)
    # print(type(TEMPLATE))
    #gpt-4-0613"
    prompt_messages = [system_message] + middle_conversation + [last_prompt]
    # Initialize OpenAI client with or without base_url
    if OPENAI_BASE_URL:
        client = OpenAI(base_url=OPENAI_BASE_URL, default_headers={
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            "Content-Type": "application/json"
        },
        http_client=custom_http_client
        )
        headers = {
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }

        data = {
            "messages": [{"role": "user", "content": f"{prompt_messages}"}],
            "temperature": 0.65 ,
            "top_p": 0.8,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 2919,
            "stop": None,
            "stream": False
        }

        response = requests.post(OPENAI_BASE_URL , headers=headers, json=data, verify=False )
        response = json.loads(response.text)
        answer = response['choices'][0]['message']['content'].strip()

    else:
        client = OpenAI()
        response = client.chat.completions.create(
            model = OPENAI_MODEL,
            messages = prompt_messages,
            temperature = 0.0
        )
        answer = response.choices[0].message.content.strip()


    print("Request URL: ", client.base_url)
    print("Request Headers: ", client.default_headers)
    print("Request Model:", OPENAI_MODEL)

    print("Response:", response)
    return answer

    pass

def predict_optimised_query(unoptimised_query: str,schema: str,tables:str,llm):
    verbose: bool = False
    
    
    
    TEMPLATE = f'''
    --- given the table details with description and columns used for joins . which are '|' seperated .
    ``
    TABLES : {tables}
    ``
    ---
    given the column details which are '|' seperated as following . 
    ```
    MATCHED_SCHEMA: {schema}


    ```
    Write a GoogleSQL dialect SQL using the above column details and tables provided in details which optimises the following unoptimised query.
    ```
    { unoptimised_query }
    ```
    IMPORTANT: Use ONLY the column names (column_name) mentioned in MATCHED_SCHEMA. DO NOT USE any other column names outside of this. 
    IMPORTANT: `` Associate column_name mentioned in MATCHED_SCHEMA only to the table_name specified under MATCHED_SCHEMA ``.
    Note : use safe divide , safe cast where ever possible. Avoid using alias names in groupby and orderby sections.
    IMPORTANT: Make sure the generated SQL has consistent spacing and correct formatting.
    IMPORTANT: Avoid GCP Project ID and Dataset reference in the output SQL.
    IMPORTANT: Optimise the query for better performance by improving indexing, using efficient joins, reducing unnecessary calculations, and avoiding redundant operations where possible
    IMPORTANT: If there is no scope of optimising the query then return the original unoptimised query itself.
    IMPORTANT: Just give the SQL query in the response

    '''
    
    # prompt = PromptTemplate(
    #     input_variables=["content","schema","tables"],
    #     template=TEMPLATE,
    #     template_format='jinja2',
    # )
    
    

    
    # prompt = TEMPLATE.format(content=content, matched_schema=schema, matched_tables=tables)
    
    # print("PromptTemplate: ", TEMPLATE)
    # print(type(TEMPLATE))
    #gpt-4-0613"
    
    # Initialize OpenAI client with or without base_url
    if OPENAI_BASE_URL:
        client = OpenAI(base_url=OPENAI_BASE_URL, default_headers={
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            "Content-Type": "application/json"
        },
        http_client=custom_http_client
        )
        headers = {
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }

        data = {
            "messages": [{"role": "user", "content": f"{TEMPLATE}"}],
            "temperature": 0.0 ,
            "top_p": 0.8,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 2919,
            "stop": None,
            "stream": False
        }

        response = requests.post(OPENAI_BASE_URL , headers=headers, json=data, verify=False )
        response = json.loads(response.text)
        answer = response['choices'][0]['message']['content'].strip()

    else:
            client = OpenAI()
            response = client.chat.completions.create(
                model = OPENAI_MODEL,
                messages = [
                    {"role": "system", "content": "You are a Big Query SQL expert and a specialist in improving query performance. Respond only with SQL query with no explanation."},
                    {"role": "user", "content": f"{TEMPLATE}"}
                ],
                temperature = 0.0
            )
            answer = response.choices[0].message.content.strip()
    
    print("Request URL: ", client.base_url)
    print("Request Headers: ", client.default_headers)
    print("Request Model:", OPENAI_MODEL)

    print("Response:", response)
    return answer

    pass


def prompt_llm(prompt):
    
    # Initialize OpenAI client with or without base_url
    if OPENAI_BASE_URL:
        client = OpenAI(base_url=OPENAI_BASE_URL, default_headers={
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            "Content-Type": "application/json"
        },
        http_client=custom_http_client
        )
        headers = {
            'HSBC-Params': f'{{"req_from":"{OPENAI_PROJECT_ID}", "type":"chat"}}',
            'Authorization-Type': 'genai',
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }

        data = {
            "messages": [{"role": "user", "content": f"{prompt}"}],
            "temperature": 0.0 ,
            "top_p": 0.8,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 2919,
            "stop": None,
            "stream": False
        }

        response = requests.post(OPENAI_BASE_URL , headers=headers, json=data, verify=False )
        response = json.loads(response.text)
        answer = response['choices'][0]['message']['content'].strip()

    else:
        client = OpenAI()
        response = client.chat.completions.create(
            model = OPENAI_MODEL,
            messages = [{"role": "user", "content": prompt}],
            temperature = 0.0
        )
        answer = response.choices[0].message.content.strip()
    
    print("Request URL: ", client.base_url)
    print("Request Headers: ", client.default_headers)
    print("Request Model:", OPENAI_MODEL)
    print("Response:", response)
    return answer

# -------------------------------------------------------------------------------  

def create_and_save_faiss(file_path, faiss_index_path, doc_store_path):
    # Load documents
    documents = JSONLoader(file_path=file_path, jq_schema='.', text_content=False, json_lines=True).load()
    
    # Create FAISS vector store
    db = FAISS.from_documents(documents=documents, embedding=embedding)

    # Save FAISS index
    db.save_local(faiss_index_path)

    # Save documents separately using pickle
    with open(doc_store_path, "wb") as f:
        pickle.dump(documents, f)
    
    print("FAISS index and document store saved successfully.")

# Function to load FAISS vector store
def load_faiss(faiss_index_path, doc_store_path):
    # Load FAISS index
    db = FAISS.load_local(faiss_index_path, embeddings=embedding, allow_dangerous_deserialization=True)
    
    # Load stored documents
    if os.path.exists(doc_store_path):
        with open(doc_store_path, "rb") as f:
            documents = pickle.load(f)
    else:
        documents = None

    return db, documents

def return_tables_matched(query, db=''):
    
    documents = JSONLoader(file_path=DB_TABLES_PATH, jq_schema='.', text_content=False, json_lines=True).load()
    db = FAISS.from_documents(documents=documents, embedding=embedding)
    retriever = db.as_retriever(search_type='mmr', search_kwargs={'k': 5, 'lambda_mult': 1})
    matched_documents = retriever.get_relevant_documents(query=query)
    matched_tables = []
    for document in matched_documents:
        page_content = document.page_content
        page_content = json.loads(page_content)
        table_name = page_content['table_name']
        desc=page_content['description']
        matched_tables.append(f'{table_name}|{desc}')
    matched_tables = '\n'.join(matched_tables)    
    return matched_tables
    pass

# -------------------------------------------------------------------------------    

def return_matched_columns(query, db):
    print("----Get Embeddings-----\n")
    documents = JSONLoader(file_path=DB_COLUMN_PATH, jq_schema='.', text_content=False, json_lines=True).load()
    db = FAISS.from_documents(documents=documents, embedding=embedding)
    search_kwargs = {
        'k': 20
    }
    retriever = db.as_retriever(search_type='similarity', search_kwargs=search_kwargs)
    matched_columns = retriever.get_relevant_documents(query=query)
    
    return matched_columns
    pass

# -------------------------------------------------------------------------------    

def return_columns_cleaned(query, db=''):
    
    matched_columns = return_matched_columns(query, db)
    
    matched_columns_filtered = []
    # LangChain filters does not support multiple values at the moment
    for i, column in enumerate(matched_columns):
        page_content = json.loads(column.page_content)
        matched_columns_filtered.append(page_content)

    matched_columns_cleaned = []
    for doc in matched_columns_filtered:
        table_name = doc['table_name']
        column_name = doc['column_name']
        data_type = doc['data_type']
        col_desc = doc['description']
        matched_columns_cleaned.append(f'table_name={table_name}|column_name={column_name}|data_type={data_type}|description={col_desc}') 
    matched_columns_cleaned = '\n'.join(matched_columns_cleaned)
    return matched_columns_cleaned
    pass

# -------------------------------------------------------------------------------    

def run_on_bq(sql):
    print(sql)
    job_config = bigquery.QueryJobConfig(default_dataset=BQ_DATASET)
    bq = bigquery.Client()
    df = bq.query(sql,job_config).to_dataframe()
    print('type',type(df))
    return df
    pass

#-------------------------------------------------------------------------------    
def get_sql_query_openai(query,llm):
    columns_schema = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    
    # Unoptimsed Query
    result=predict(query,columns_schema,tables,llm)
    # print("output sql query", result)
    cleaned_sql = result.replace('```', '').replace('sql','')
    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    # print('sql', cleaned_sql_1)
    # sql=result.replace('```', ''''')
    
    # Optimised Query
    result_optimised = predict_optimised_query(cleaned_sql_1, columns_schema, tables, llm)
    cleaned_optimised_sql = result_optimised.replace('```', '').replace('sql','')
    cleaned_optimised_sql_1 = ' '.join(cleaned_optimised_sql.split())

    return cleaned_sql_1, cleaned_optimised_sql_1, columns_schema, tables
    pass

## Created by KP
def get_unoptimised_sql_query_openai(query,llm):
    columns_schema = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    
    # Unoptimsed Query
    result=predict(query,columns_schema,tables,llm)
    print("output sql query", result)
    cleaned_sql = result.replace('```', '').replace('sql','')
    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    print('sql', cleaned_sql_1)
    # sql=result.replace('```', ''''')

    return cleaned_sql_1, columns_schema, tables
    pass

def get_optimised_sql_query_openai(query, llm):
    columns_schema = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    
    # Optimised Query
    result_optimised = predict_optimised_query(query, columns_schema, tables, llm)
    cleaned_optimised_sql = result_optimised.replace('```', '').replace('sql','')
    cleaned_optimised_sql_1 = ' '.join(cleaned_optimised_sql.split())

    return cleaned_optimised_sql_1, columns_schema, tables
    pass

def generate_sql(query, columns_schema, tables):
    
    llm = "openai"
    
    result=predict(query,columns_schema,tables,llm)
    
    sql = result.replace('```', '').replace('sql','')
    
    sql = ' '.join(sql.split())
    
    return sql
#------------------------------------------------------------------------------- 
def get_sql_query_vertexai(query,llm):
    columns_schema = return_columns_cleaned(query)
    tables= return_tables_matched(query)
    request = vertex_prompt.format_prompt(query=query,matched_schema=columns_schema,matched_tables=tables)
    response = llm(request.to_messages())
    sql = response.content.strip()
    cleaned_sql = sql.replace('```', '').replace('sql','')
    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    #sql = response.content.strip().replace('sql',' ').replace('``',' ')
    #sql = response.content.strip().replace('sql','')
    return cleaned_sql_1, columns_schema, tables

#------------------------------------------------------------------------------- 
def get_sql_query_geminiai(query,MODEL_NAME):
    columns_schema = return_columns_cleaned(query)
    tables = return_tables_matched(query)
    prompt = gemini_prompt.format(content=query,matched_tables=tables,matched_schema=columns_schema)
    model = GenerativeModel(MODEL_NAME)
    responses = model.generate_content(
        prompt,
        generation_config={
            "temperature": 0.0,
            "max_output_tokens":2048,
        },
        stream=False
    )
    sql = responses.text.strip()
    cleaned_sql = sql.replace('```', '').replace('sql','').replace('**', '').replace('#', '')

    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    
    # print('sql', cleaned_sql_1)
    
    return cleaned_sql_1, columns_schema, tables

# ------------------------------------------------------------------------------#

def get_sql_query_geminiai15pro(query,MODEL_NAME= "gemini-1.5-pro-preview-0215"):
    
    columns_schema = return_columns_cleaned(query)
    tables = return_tables_matched(query)
    prompt = gemini_prompt.format(content=query,matched_tables=tables,matched_schema=columns_schema)
    model = GenerativeModel(MODEL_NAME)
    responses = model.generate_content(
        prompt,
        generation_config={
            "temperature": 0.0,
            "max_output_tokens":2048,
        },
        stream=False
    )
    sql = responses.text.strip()
    cleaned_sql = sql.replace('```', '').replace('sql','')

    cleaned_sql_1 = ' '.join(cleaned_sql.split())
    
    # print('sql', cleaned_sql_1)
    
    return cleaned_sql_1, columns_schema, tables


# -------------------------------------------------------------------------------#

def generate_visualization(df, color_scheme='Plasma'):
    cols = df.columns 
    col_x = cols[-2]
    col_y = cols[-1]
    
    print("X Column data type:", df[col_x].dtype)
    print("Y Column data type:", df[col_y].dtype)
    
    # Determine the type of plot based on the data type of the columns
    if df[col_x].dtype == 'object' or df[col_y].dtype == 'object':
        # Bar plot for categorical data
        fig = px.bar(df, x=col_x, y=col_y, title='Insight Visualization', color=col_y, color_continuous_scale=color_scheme)
    elif df[col_x].dtype == 'datetime':
        # Line plot for time series data
        fig = px.line(df, x=col_x, y=col_y, title='Insight Visualization', color=col_y, color_continuous_scale=color_scheme)
    else:
        # Scatter plot for numerical data
        fig = px.scatter(df, x=col_x, y=col_y, title='Insight Visualization', color=col_y, color_continuous_scale=color_scheme)
    
    fig.show()
    fig.write_image("image_desc.png")
#-------------------------------------------------------------------------------
def sample_gen(df,query,tables, columns, llm_type):
    if llm_type == 'llama':
        sample = describe_bot(f"""
                    <s>[INST] <<SYS>>
                    You are a helpful assistant and based on the context answer users question.
                    context :  values:{df}, metadeta:{md_map}
                    <</SYS>>
        
                     and give me a top 5 insights of this data in bullet points on seperate lines.
                    [/INST]
                    """,llm_type)
    else:
    #sample = describe_bot(f'''give me top 3 sample question to generate sql queries looking at this data : {df}''',llm_type)
        sample = describe_bot(f'''Give me top three follow up analytical business query to the following business query:-
        {query}
        and following table and columns:-
        Tables: {tables}
        Columns:{columns}
        based on this data: 
        {df}
        Note: Follow up queries should have corresponding valid SQL queries based on the tables and columns mentioned above to fetch the data from database.Don't print the SQL query along with the question. Just print the questions.
        Note: Don't highlight the words or give any headings. just print 3 questions in seperate lines without ordering. In the following format:
        question1\nquestion2\nquestion3 
        NOTE: All three questions should be valid follow up question to the main query and different from each other''',llm_type)
    return sample
    pass
#-------------------------------------------------------------------------------
def main():
    
    st.title('Automated BI: Text2Insights 📈')
    main_placeholder = st.empty()
    question = st.text_input('Enter your question:')
    llm_type = st.selectbox('Select LLM Type:', ['openai', 'palm2','gemini-pro'])
    sql_query=''
    if st.button('Generate'):
        try:
            if llm_type =='openai':
                main_placeholder.text(f"!!  Running on OpenAI!!")
                llm=ChatOpenAI(model_name="gpt-4-1106-preview", temperature=0)
                sql_query = get_sql_query_openai(question,llm)
                
            elif llm_type =='palm2':
                main_placeholder.text(f"!!  Running on Palm2 !!")
                PROJECT = 'techsteer'
                LOCATION = 'us-central1'
                MODEL_NAME = 'codechat-bison@002'
                llm = ChatVertexAI(project=PROJECT,location=LOCATION,model_name=MODEL_NAME,
                                   temperature=0.0,max_output_tokens=2048)
                sql_query = get_sql_query_vertexai(question,llm)
                
            elif llm_type =='gemini-pro':
                main_placeholder.text(f"!!  Running on Gemini-Pro LLM !!")
                PROJECT = 'techsteer'
                LOCATION = 'us-central1'
                MODEL_NAME = "gemini-pro"
                sql_query = get_sql_query_geminiai(question,MODEL_NAME)
                
            elif llm_type =='llama':
                main_placeholder.text(f"!!  Running on Llama 2 LLM !!")
                PROJECT = 'techsteer'
                LOCATION = 'us-central1'
                MODEL_NAME = 'codechat-bison@002'
                llm = ChatVertexAI(project=PROJECT,location=LOCATION,model_name=MODEL_NAME,
                                   temperature=0.0,max_output_tokens=4096)
                sql_query = get_sql_query_vertexai(question,llm)
           
            st.write('Generated SQL:')
            st.write(sql_query)
            df = run_on_bq(sql_query)
            st.write('DataFrame:', df)
            row_count = df.shape[0]
            column_count = df.shape[1]
            if row_count > 1 and column_count>1 :
                md_map = df.dtypes.to_dict()
                if llm_type == 'llama':
                    describe_prompt =f"""
                    <s>[INST] <<SYS>>
                    Assume you are a data analyst look into these context generated for my question which was '{question}'.
                    context :  values:{df}, metadeta:{md_map}
                    <</SYS>>
        
                     and give me a top 5 insights of this data in bullet points on seperate lines.
                    [/INST]
                    """
                else:
                    describe_prompt = f"""Assume you are a data analyst look into these values generated for my question which was '{question}' and give me a top 5 insights of this data in bullet points on seperate lines . values:{df}, metadeta:{md_map} """
                    
                description = describe_bot(describe_prompt, llm_type)
                st.write('Data Insights:', description)
                sample_prompts = sample_gen(df,llm_type)
                st.write('Sample Prompts:')
                st.write(sample_prompts) 
                
            if row_count>1 and column_count >1 and column_count < 3:
                generate_visualization(df)
                st.image('image_desc.png', caption='')        
                
        except Exception as e:
            main_placeholder.text(f"Unable to generate results . please correct the query.{e} !!")
            
 #-------------------------------------------------------------------------------          

if __name__ == '__main__':
    main()
